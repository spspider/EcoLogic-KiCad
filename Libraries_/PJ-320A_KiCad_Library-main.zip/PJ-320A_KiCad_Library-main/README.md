# PJ-320A_KiCad_Library
This repository contains libraries for the PJ-320A 3.5mm Audio Jack Connector.

# ScreenShots

![PJ-320A Symbol](https://user-images.githubusercontent.com/75147239/122315563-504ead00-cee8-11eb-93b0-451fc22a34fb.PNG)

![PJ-320A footprint](https://user-images.githubusercontent.com/75147239/122315807-c0f5c980-cee8-11eb-840a-af84a95081d5.PNG)

# Reference Data Sheet
![PJ-320A dimensions](https://user-images.githubusercontent.com/75147239/122315882-e5ea3c80-cee8-11eb-90d4-26e39fa01083.jpg)
